import java.util.*;

public class CharSorter {

   private static int[] alphabeticalSort(String text) //sorts all chars in an array with position respective to their ASCII value minus 32.
   {
       int[] alphabeticalList = new int[95];

       for (int n = 0; n < text.length(); n++)
           alphabeticalList[(int)(text.charAt(n)) - 32]++;

    return alphabeticalList;
   }

   private static void frequencySort(int[] sortedText) //sorts all values in an array greatest to least.
   {

       String[] frequencySort = new String[sortedText.length];

       for (int n = 0; n < sortedText.length; n++)
           frequencySort[n] = ((char)(n + 32) + "" + sortedText[n]);

       for (int x = frequencySort.length; x >= 0; x--) {
           for (int y = frequencySort.length - 1; y > 0; y--) {

               int current = Integer.parseInt(frequencySort[y].substring(1, frequencySort[y].length()));
               int test = Integer.parseInt(frequencySort[y - 1].substring(1, frequencySort[y - 1].length()));

               if (current > test) {
                   String tempVal = frequencySort[y - 1];
                   frequencySort[y - 1] = frequencySort[y];
                   frequencySort[y] = tempVal;
               }
           }
       }
       System.out.print("\nThe sorted by frequency characters are:\n");
       for (int n = 0; n < frequencySort.length ; n++) {
           if (Integer.parseInt(frequencySort[n].substring(1, frequencySort[n].length())) == 0)
               continue;
           System.out.print("\n" + frequencySort[n].substring(0, 1) + " ");
           System.out.print("freq: ");
           System.out.print(frequencySort[n].substring(1, frequencySort[n].length()));
       }
       System.out.print("\n\n");
   }

   private static void charTypes(int[] sortedText) //groups all values of the same type then prints them to the console.
   {
       int[] charFreq = new int[4];
       charFreq[2] += sortedText[0];

       for (int n = 1; n < sortedText.length; n++) {
           if (n > 15 && n <  26)
               charFreq[1] += sortedText[n];
           else if (n > 32 && n < 59 || n > 64 && n <  91)
               charFreq[0] += sortedText[n];
           else
               charFreq[3] += sortedText[n];
       }

       System.out.println("\nTextual Character count: " + charFreq[0]);
       System.out.println("Numerical Character count: " + charFreq[1]);
       System.out.println("WhiteSpace Character count: " + charFreq[2]);
       System.out.println("Symbol Character count: " + charFreq[3] + "\n");

   }

    public static void main(String[] args) {

        Scanner scnr = new Scanner(System.in);
        String inputFile;

        System.out.println("Welcome to Character Sorter Program");
        System.out.println("Please input a string to be sorted");
        inputFile = scnr.nextLine(); //obtains the file to be sorted

        int[] freqAlphabetical = alphabeticalSort(inputFile); //creates a new array of char frequencies in alphabetical order.

        while(true) {
            int userInput = 0;
            System.out.println("\nPlease select the option you would like to see\n");
            System.out.println("1. Display character frequencies alphabetically\n" +
                               "2. Display sorted frequencies\n" +
                               "3. Show types of character frequencies\n" +
                               "4. Exit");

            //catches all user input errors.
            try {
                userInput = scnr.nextInt();
            }
            catch (InputMismatchException e) {
                System.out.println("\nError, bad input, please enter a number 1-4");
                scnr.nextLine();
                continue;
            }

            if (userInput == 1) {
                System.out.println();
                for (int n = 0; n < freqAlphabetical.length; n++) {
                    if (freqAlphabetical[n] == 0)
                        continue;
                    System.out.println((char)(n + 32) + " freq:  " + freqAlphabetical[n]);
                }
                System.out.println();
            }
            else if (userInput == 2)
                frequencySort(freqAlphabetical);

            else if (userInput == 3)
                charTypes(freqAlphabetical);

            else if (userInput == 4) {
                System.out.println("\nCharacter Sorter Exited Successfully");
                break;
            }
            else
                System.out.println("\nError, bad input, please enter a number 1-4");
        }
    }

}