import java.util.Scanner;
import java.util.InputMismatchException;

public class BlackJack {
    private static void printStats(int pw, int dw, int tg, int tgp) {
        System.out.println("Number of Player wins: " + pw);
        System.out.println("Number of Dealer wins: " + dw);
        System.out.println("Number of tie games: " + tg);
        System.out.println("Total # of games played: " + tgp);
        if (tgp == 0) {
            System.out.println("Percentage of Player wins: 0%\n"); //if no games were played then the players win percentage is 0%.
        }
        else {
            System.out.println("Percentage of Player wins: " + (Math.round(((double)pw / (double)tgp) * 100.0) + 0.0) + "%\n"); //calculates player win percentage.
        }
    } //prints the statistics of the secession.

    private static void printReceivedCard(int c) {
        if (c == 1) {
            System.out.println("\nYour card is an ACE!");
        }
        else if (c <= 10) {
            System.out.println("\nYour card is a " + c + "!");
        }
        else if (c == 11) {
            System.out.println("\nYour card is a JACK!");
        }
        else if (c == 12) {
            System.out.println("\nYour card is a QUEEN!");
        }
        else if (c == 13) {
            System.out.println("\nYour card is a KING!");
        }
    } //prints out which card you were randomly given.

    private static int getCard() {
        int cv = (int)(Math.random() * 13 + 1); //gets a random number between [1, 13].
        printReceivedCard(cv); //calls printReceivedCard.
        if (cv > 10) { // sets any card above 10 to 10.
            cv = 10;
        }
        return cv; //returns the card value.
    } //gets a player a random number [1, 13] then calls printReceivedCard.

    public static void main(String[] args) {

        Scanner userInput = new Scanner(System.in); //Scanner used to get user input.
        int playerHandTotal, dealerHandTotal; //hand totals for the player and dealer.
        int playerWins = 0; //amount of player wins.
        int dealerWins = 0; //amount of dealer wins.
        int tieGames = 0; //amount of tie games.
        int totalGamesPlayed = 0; //amount of games played.
        int inputValue; //player's game choice.

        while (true) { //Continually runs the game
            System.out.println("START GAME #" + (totalGamesPlayed + 1)); //prints which game you are on.
            playerHandTotal = 0; //resets playersHandTotal to 0.
            inputValue = 0; //resets the inputValue to 0.

            playerHandTotal += getCard(); //prints a random card and adds it to the player's hand.
            System.out.println("Your hand is: " + playerHandTotal + "\n"); //tells the player their hand total.

            while ((inputValue != 2) && (playerHandTotal < 21)) { //loops a players hand until they input 2 or have a hand 21 or higher.
                System.out.println("1. Get another card\n" + "2. Hold hand\n" + "3. Print statistics\n" + "4. Exit\n"); //prints game options.
                System.out.print("Choose an option: ");
                inputValue = 0; //resets inputValue.

                try { //tries to see if there is any input errors.
                    inputValue = userInput.nextInt(); //reads userInput.
                }
                catch (InputMismatchException notInt) { //catches userInput exceptions.
                    userInput.nextLine();
                }

                if (inputValue == 1) { //checks player input for 1.
                    playerHandTotal += getCard(); //prints a random card added to a players hand.
                    System.out.println("Your hand is: " + playerHandTotal + "\n"); //tells the player their hand total.
                }
                else if (inputValue == 3) { //checks player input for 3.
                    System.out.println();
                    printStats(playerWins, dealerWins, tieGames, totalGamesPlayed); //calls printStats.
                }
                else if (inputValue == 4) { //checks player input for 4.
                    return; //terminates the program.
                }
                else if (inputValue != 2) {
                    System.out.println("\nInvalid input! \nPlease enter an integer value between 1 and 4\n");
                }
            }

            if (playerHandTotal == 21) { //checks for blackjack.
                System.out.println("BLACKJACK! You win!\n");
                playerWins++; //adds 1 to playerWins.
            }
            else if (playerHandTotal > 21) { //checks if the player flops.
                System.out.println("You exceeded 21! You lose :(\n");
                dealerWins++; //adds 1 to dealerWins.
            }
            else {
                dealerHandTotal = (int)((Math.random() * 11 + 16)); //gets a random number between [16, 26].
                System.out.println("\nDealer's Hand: " + dealerHandTotal + "\nYour hand is: " + playerHandTotal + "\n");

                if (dealerHandTotal > 21) { //checks to see if dealer flops.
                    System.out.println("You win!\n");
                    playerWins++; //adds one to playerWins.
                } else if (dealerHandTotal > playerHandTotal) { //checks if the dealer beat the player.
                    System.out.println("Dealer wins!\n");
                    dealerWins++; //adds on to dealerWins.
                } else if (playerHandTotal > dealerHandTotal) { //checks if the player beat the dealer.
                    System.out.println("You win!\n");
                    playerWins++; //adds one to playerWins.
                } else {
                    System.out.println("It's a tie! No one wins!\n");
                    tieGames++; //adds one to tieGames.
                }
            }
            totalGamesPlayed++; //adds one to totalGamesPlayed.
        }

    } //game.
}
