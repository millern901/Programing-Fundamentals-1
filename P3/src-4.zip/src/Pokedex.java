import java.util.*;

public class Pokedex {

    //fields
    private ArrayList<Pokemon> entries;

    //creates a Pokedex with a parameter of size to initialize its ArrayList of Pokemon
    public Pokedex(int size) {
        entries = new ArrayList<Pokemon>(size);
    }

    //creates a string of all the names of the Pokemon in a particular Pokedex.
    public String[] listPokemon() {
        String[] list = new String[entries.size()];

        for (int n = 0; n < entries.size(); n++) {
            list[n] = entries.get(n).getSpecies();
        }
        return list;
    }

    //adds a Pokemon to the Pokedex
    public boolean addPokemon(String species) {
        if (searchPokemon(species) > -1)
            return false;
        else {
            entries.add(new Pokemon(species));
            return true;
        }
    }

    //obtains the stats of a specific Pokemon
    public int[] checkStats(String species) {
        int[] stats = new int[3];
        int index = searchPokemon(species);

        stats[0] = entries.get(index).getAttack();
        stats[1] = entries.get(index).getDefense();
        stats[2] = entries.get(index).getSpeed();

        return stats;
    }

    //sorts Pokedex using quicksort
    public void sortPokedex() {
        Collections.sort(entries);
    }

    //returns the index of a Pokemon or -1 if the Pokemon isn't in the Pokedex
    public int searchPokemon(String species) {
        if (entries.isEmpty()) {
            return -1;
        }
        for (int n = 0; n < entries.size(); n++) {
            if (species.toLowerCase().equals(entries.get(n).getSpecies().toLowerCase()))
               return n;
        }
        return -1;
    }

    //evolves a Pokemon if it is in the ArrayList
    public boolean evolvePokemon(String species) {
        int index = searchPokemon(species);
        if (index > -1) {
            entries.get(index).evolve();
            return true;
        }
        return false;
    }

}
