import java.util.*;

public class Main {
    public static void main(String[] args) {

       Scanner scanner = new Scanner(System.in);
       int userInput = 0;
       String species = "";
       int max = 0;
       int current = 0;

       //defines the size of your Pokedex
        while (userInput <= 0) {
            System.out.print("Welcome to your new Pokedex!\nHow many Pokemon are in your region: ");
            try {
                userInput = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("\nThat is not a valid choice. Try again.\n");
                scanner.nextLine();
                userInput = 0;
                continue;
            }
            if (userInput <= 0)
                System.out.println("\nThat is not a valid choice. Try again.\n");
        }
            System.out.println("\nYour new Pokedex can hold " + userInput + " Pokemon. Let’s start using it!");
            Pokedex pokedex = new Pokedex(userInput);
            max = userInput;

       //loops through the game
       while (true) {
           userInput = 0;
           System.out.println("\n1. List Pokemon\n" + "2. Add Pokemon\n" + "3. Check a Pokemon’s Stats\n" +
                                  "4. Evolve Pokemon\n" + "5. Sort Pokemon\n" + "6. Exit\n");
           System.out.print("What would you like to do? ");

           //trys user input
           try {
               userInput = scanner.nextInt();
           }
           catch (InputMismatchException e) {
               System.out.println("\nThat is not a valid choice. Try again.");
               scanner.nextLine();
               continue;
           }

           //does each corresponding action based on user input
           if (userInput == 1) {
               String[] list = pokedex.listPokemon();
               for (int n = 0; n < list.length; n++) {
                   System.out.println("" + (n + 1) + ". " + list[n]);
               }
           }
           else if (userInput == 2) {
               scanner.nextLine();
               System.out.print("\nPlease enter the Pokemon’s Species: ");
               species = scanner.nextLine();
               if (current < max) {
                   int index = pokedex.searchPokemon(species);
                   if (index < 0) {
                       pokedex.addPokemon(species);
                       current++;
                   }
                   else System.out.println("Duplicate");
               }
               else System.out.println("Max");
           }
           else if (userInput == 3) {
               scanner.nextLine();
               System.out.print("\nPlease enter the Pokemon of interest: ");
               species = scanner.nextLine();
               int index = pokedex.searchPokemon(species);
               if (index < 0) {
                   System.out.println("Missing");
               }
               else {
                   int[] checkStats = pokedex.checkStats(species);
                   System.out.println("\nThe stats for " + species + " are:");
                   System.out.println("Attack: " + checkStats[0]);
                   System.out.println("Defense: " + checkStats[1]);
                   System.out.println("Speed: " + checkStats[2]);
               }
           }
           else if (userInput == 4) {
               scanner.nextLine();
               System.out.print("\nPlease enter the Pokemon of interest: ");
               species = scanner.nextLine();
               int index = pokedex.searchPokemon(species);
               if (index < 0) {
                   System.out.println("Missing");
               }
               else {
                   pokedex.evolvePokemon(species);
                   System.out.println(species + " has evolved!");
               }

           }
           else if (userInput == 5) {
               pokedex.sortPokedex();
           }
           else if (userInput == 6) {
               break;
           }
           else {
               System.out.println("\nThat is not a valid choice. Try again.");
           }

       }
    }
}
