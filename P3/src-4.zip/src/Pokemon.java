import java.util.*;

public class Pokemon implements Comparable<Pokemon>{

    //fields
    private String species;
    private int attack, defense, speed;

    //base constructor
    public Pokemon() {
        species = "";
        attack = 0;
        defense = 0;
        speed = 0;
    }

    //constructor used to initialize values
    public Pokemon(String species) {
        this.species = species;
        attack = species.length() * 4 + 2;
        defense = species.length() * 2 + 7;
        speed = species.length() * 3 + 5;
    }

    //getters
    public String getSpecies() {
        return species;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }

    public int getSpeed() {
        return speed;
    }

    //setters
    public void setSpecies(String species) {
        this.species = species;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    //evolves the pokemon
    public void evolve() {
        setSpeed(2 * getSpeed());
        setAttack(3 * getAttack());
        setDefense(5 * getDefense());
    }

    //compare method used to compare one Pokemon to another pokemon
    public int compareTo(Pokemon other) {
        return this.species.compareTo(other.species);
    }


}
